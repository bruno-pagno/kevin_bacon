/*
Nome: Bruno de Sousa Pagno		NUSP: 11366872
Nome: João Vitor de Mello Gomes	NUSP: 11218622
Professor: Elaine Parros Machado de Sousa
Disciplina: SCC0503
*/

#ifndef _KEVIN_BACON_
#define _KEVIN_BACON_

#include <stdio.h>
#include <stdlib.h>

/* Defines */


/* Headers */
int show_menu();
void read_input();


#endif