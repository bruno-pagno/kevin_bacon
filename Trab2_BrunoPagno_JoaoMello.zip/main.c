/*
Nome: Bruno de Sousa Pagno		NUSP: 11366872
Nome: João Vitor de Mello Gomes	NUSP: 11218622
Professor: Elaine Parros Machado de Sousa
Disciplina: SCC0503
*/

/*
OBSERVAÇÕES:
    criei esse main.c pras funcoes entre os .h

	o valor das arestas vai ser o titulo do filme
	o valor dos vértices vai ser o nome do ator
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <graph.h>

#define DEBUG 0
#define FILE_NAME "input-top-grossing.txt"

int showMenu();
void readInsertInputs(GRAPH *);
void printAdjacents(GRAPH *);

int main() {
	GRAPH * graph = create_graph(); /* Cria o grafo */ 
	readInsertInputs(graph);

	/* Interação com o usuário */
	int result = 1;
	while(result == 1 || result == 2){
		result = showMenu();
		switch(result) {
			case 1:
				printAdjacents(graph);
				break;
			case 2:
				printf("a\n");
				break;
		}
	}

	if(DEBUG)
		printf("Result is %d\n", result);
	printf("Finalizando execução e liberando o grafo ... \n");
	/* liberar grafo */
	return 0;
}

/* Funçoes */
int showMenu() {
	int result = 0;
	printf("\n");
	printf("|------------------------MENU------------------------|\n");
	printf("|1 - Consultar numero de Kevin Bacon de um ator/atriz|\n");
	printf("|2 - Média / Desvio Padrão do universo Kevin Bacon   |\n");
	printf("|3 - Sair do programa                                |\n");
	printf("|----------------------------------------------------|\n");
	scanf("%d", &result);
	
	return result;
}

MOVIE * __newMovie(char movie_name[]) {
	MOVIE *movie = (MOVIE *) malloc(sizeof(MOVIE));
	strcpy(movie->movie_name, movie_name);
	movie->num_actors = 0;
	movie->actors_indexes = NULL;

	return movie;
}

void __addActor(MOVIE *movie, int index) {
	movie->actors_indexes = (int *) realloc(movie->actors_indexes, (movie->num_actors + 1) * sizeof(int));
	movie->actors_indexes[movie->num_actors++] = index;
}

void __addEdges(GRAPH *graph, MOVIE *movie) {
	int i = 0, j;
	int movie_index = getMovieIndex(graph, movie->movie_name);
	for(; i < movie->num_actors; i++)
		for(j = i + 1; j < movie->num_actors; j++) {
			insertEdge(graph, movie->actors_indexes[i], movie->actors_indexes[j], movie_index);
			insertEdge(graph, movie->actors_indexes[j], movie->actors_indexes[i], movie_index);
		}
	if(DEBUG) printf("%d atores relacionados\n", movie->num_actors);
		
}

void __readLine(FILE *arq_input, char line[]) {
	/* leitura das linhas por completo */
	char aux;
	int i = 0;
	while(fscanf(arq_input, "%c", &aux) != EOF && aux != '\n')
		line[i++] = aux;
	line[i] = '\0';
}

void readInsertInputs(GRAPH * graph) {
	FILE *arq_input = fopen(FILE_NAME, "r");
	if(!arq_input) {
		printf("Erro ao abrir arquivo...\n");
		exit(0);
	}

	char line[2000];
	__readLine(arq_input, line);
	while(strlen(line)) {	/* para cada filme */
		if(DEBUG) printf("\n\t%s\n", line);	/* linha toda */
		
		MOVIE *movie = __newMovie(strtok(line, "/"));

		char *actor_name = strtok(NULL, "/");
		while(actor_name) {	/* para cada ator */
			int actor_index = insertVertex(graph, actor_name);
			__addActor(movie, actor_index);

			if(DEBUG) printf("\t%s\t(%d)\n", actor_name, actor_index);
			
			actor_name = strtok(NULL, "/");
		}

		int movie_index = insertMovie(graph, movie->movie_name);
		if(DEBUG)
			printf("\t\tO filme %s é o %dº filme, com %d atores\n", movie->movie_name, movie_index + 1, movie->num_actors);

		__addEdges(graph, movie);

		__readLine(arq_input, line);
	}
	if(DEBUG)
		printf("%d atores contabilizados\n", graph->num_vertex);
}

void printAdjacents(GRAPH *graph) {
	char actor_name[30];
	printf("\tDigite o nome do ator: ");
	scanf(" %[^\n]s", actor_name);

	int actor_index = getActorIndex(graph, actor_name);
	if(actor_index == VAZIO)
		printf("Não encontrado...\n");
	else {
		int i = 0;
		printf("\n");
		for(; i < graph->num_vertex; i++) {
			int movie_index = graph->edges[actor_index][i];
			if(movie_index != VAZIO) {
				char other_actor[30];
				char movie_name[60];
				strcpy(other_actor, graph->actors_names[i]);
				strcpy(movie_name, graph->movies_names[movie_index]);
				
				printf("\t%s atuou com %s em %s\n", actor_name, other_actor, movie_name);
			}
		}
	}
}